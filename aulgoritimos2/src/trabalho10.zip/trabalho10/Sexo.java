package trabalho10;

public enum Sexo {
    MASCULINO("masculino") , FEMININO("feminino") ;
    public String nome ;
    Sexo(String nome ){
        this.nome = nome ;
    }
}
