package trabalho10;
/*
Desenvolva uma programa em Java que:

- Adicione 4 Pessoas em uma lista;
    Crie uma classe Pessoa contendo o nome, cpf e sexo como atributos;              -- ok --
    Sobrescreva o método toString da classe Pessoa;                                 -- ok --
    Sexo deve ser um enum;                                                          -- ok --
    Deve-se solicitar os dados ao usuário para o preenchimento da lista.            -- ok --
- Imprimir todos os dados da lista;                                                 -- ok --
    Utilizar o seguinte método: public static void imprimirTudo(List<Pessoa> lista);-- ok --
- Após imprimir deve remover todas as pessoas do sexo masculino.                    -- ok --
- Imprimir todos os dados da lista novamente (Utilizando o método anterior).        -- ok --
*/